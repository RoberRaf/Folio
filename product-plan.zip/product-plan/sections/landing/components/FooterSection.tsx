import type { FooterData } from '../types'

function InstagramIcon() {
  return (
    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
    </svg>
  )
}

function TwitterXIcon() {
  return (
    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.745l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  )
}

function SocialIcon({ platform }: { platform: string }) {
  if (platform === 'Instagram') return <InstagramIcon />
  if (platform === 'Twitter') return <TwitterXIcon />
  return <span className="text-xs font-mono">{platform}</span>
}

interface FooterSectionProps {
  footer: FooterData
}

export function FooterSection({ footer }: FooterSectionProps) {
  return (
    <footer className="bg-stone-950 border-t border-stone-800/60">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 py-16 sm:py-20">
        <div className="flex flex-col items-center gap-8">
          <div className="flex flex-col items-center gap-2">
            <span className="text-4xl font-bold text-white tracking-tight" style={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic' }}>Folio</span>
            <span className="text-stone-600 text-xs tracking-[0.18em] uppercase font-mono">Beautiful Photo Books</span>
          </div>
          <div className="flex items-center gap-3 w-full max-w-xs">
            <div className="h-px flex-1 bg-stone-800" />
            <div className="w-1.5 h-1.5 rounded-full bg-rose-500/60" />
            <div className="h-px flex-1 bg-stone-800" />
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-5 sm:gap-6">
            <a href={`mailto:${footer.email}`} className="text-stone-400 hover:text-rose-300 transition-colors duration-200 text-sm font-mono">{footer.email}</a>
            <span className="hidden sm:block w-1 h-1 rounded-full bg-stone-700" />
            <div className="flex items-center gap-5">
              {footer.socialLinks.map((link) => (
                <a key={link.platform} href={link.href} target="_blank" rel="noopener noreferrer" aria-label={link.platform} className="text-stone-500 hover:text-rose-400 transition-colors duration-200">
                  <SocialIcon platform={link.platform} />
                </a>
              ))}
            </div>
          </div>
          <p className="text-stone-700 text-xs font-mono tracking-wide">{footer.copyright}</p>
        </div>
      </div>
    </footer>
  )
}
